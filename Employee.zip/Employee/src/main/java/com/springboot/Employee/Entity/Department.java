package com.springboot.Employee.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "DEPARTMENT_DETAILS")
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column (name = "JOB_ID")
	private long job_id;
	@Column(name = "DEPARTMENT_ID")
	private long department_id;
	@Column(name = "DEPARTMENT_NAME")
	private String department_name;
	@Column(name = "EMPLOYEE_FIRSTNAME")
	private String employee_firstname;
	@Column(name = "EMPLOYEE_LASTNAME")
	private String employee_lastname;
	@Column(name = "EMPLOYEE_SALARY")
	private float employee_salary;
	@Column(name = "EMPLOYEE_JOININGDATE")
	private String employee_joiningdate;
	@Column(name = "EMPLOYEE_ID")
	private long employee_id;
}