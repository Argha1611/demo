package com.springboot.Employee.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "DEPARTMENT_DETAILS")
public class Project {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EMPLOYEE_PROJECTID")
	private int project_id;
	@Column(name = "PROJECT_NAME")
	private String project_name;
	@Column(name = "PROJECT_STARTINGDATE")
	private String project_startingdate;
	@Column(name = "PROJECT_ENDINGDATE")
	private String project_endingdate;
	@Column(name = "PROJECT_LOCATION")
	private String project_location;
	@Column(name = "EMPLOYEE_FIRSTNAME")
	private String employee_firstname;
	@Column(name = "EMPLOYEE_LASTNAME")
	private String employee_lastname;
	@Column(name = "EMPLOYEE_ID")
	private long employee_id;
}