package com.springboot.Employee.Service;
import java.util.List;
import com.springboot.Employee.Entity.Department;
public interface DepartmentService {
	Department addDepartment(Department department);
	List<Department> fetchAllDepartments();
	Department getDepartmentById(int id);
	Department updateDepartmentById(int id, Department department);
	String deleteDepartmentById(int id);
}
