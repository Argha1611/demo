package com.springboot.Employee.Service;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.Employee.Entity.Department;
import com.springboot.Employee.Repository.DepartmentRepo;
@Service
public class DepartmentImpl implements DepartmentService {
	@Autowired
	DepartmentRepo departmentRepo;
	@Override
	public Department addDepartment(Department department) 
	{
		return departmentRepo.save(department);
	}
	@Override
	public List<Department> fetchAllDepartments() 
	{
		List<Department> allDepartment = department.Repo.findAll();
		return allDepartment;
	}
	@Override
	public Department getDepartmentById(int id) 
	{
		Optional<Department> department = departmentRepo.findById(id);
		if (department.isPresent())
		{
			return department.get();
		}
		return null;
	}
	@Override
	public Department updateDepartmentById(int id, Department department)
	{
		Optional<Department> department1 = department.Repo.findById(id);
		return null;
	}
	@Override
	public String deleteDepartmentById(int id) 
	{
		if(departmentRepo.findById(id).isPresent())
		{
			departmentRepo.deleteById(id);
			return "Department deleted successfully";
		}
		return "No such department in the database";
	}
}