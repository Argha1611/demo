package com.springboot.Employee.Entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "EMPLOYEE_DETAILS")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EMPLOYEE_ID")
	private long employee_id;
	@Column(name = "EMPLOYEE_FIRSTNAME")
	private String employee_firstname;
	@Column(name = "EMPLOYEE_LASTNAME")
	private String employee_lastname;
	@Column(name = "EMPLOYEE_GENDER")
	private String employee_gender;
	@Column(name = "EMPLOYEE_AGE")
	private int employee_age;
	@Column(name = "EMPLOYEE_LOCATION")
	private String employee_location;
	@Column(name = "EMPLOYEE_MOBILENUMBER")
	private long employee_mobilenumber;
	@Column(name = "EMPLOYEE_EMAILID")
	private String employee_emailid;
	@Column(name = "EMPLOYEE_DESIGNATION")
	private String employee_designation;
	@Column(name = "EMPLOYEE_QUALIFICATION")
	private String employee_qualification;
	@Column(name = "EMPLOYEE_DEPARTMENT")
	private String employee_department;
	@Column(name = "EMPLOYEE_PROJECTID")
	private int project_id;
}