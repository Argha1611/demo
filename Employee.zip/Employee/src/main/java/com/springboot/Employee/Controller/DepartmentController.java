package com.springboot.Employee.Controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.Employee.Entity.Department;
import com.springboot.Employee.Service.DepartmentService;
@RestController
public class DepartmentController {
	@Autowired
	DepartmentService departmentService;
	@PostMapping("/addDepartment")
	public Department addDepartment(@RequestBody Department department) 
	{
		return departmentService.addDepartment(department);
	}
	@GetMapping("/getDepartment")
	public List<Department>getAllDepartment() 
	{
		return departmentService.fetchAllDepartments();
	}
	@GetMapping("/getDepartment/{id}")
	public Department getDepartmentById(@PathVariable("id")int id) 
	{
		return departmentService.getDepartmentById(id);		
	}
	@PutMapping("/department/{id}")
	public Department updateDepartment(@PathVariable("id") int id, @RequestBody Department department) 
	{
		return departmentService.updateDepartmentById(id, department);
	}
	@DeleteMapping("/department/{id}")
	public String deleteDepartment(@PathVariable("id") int id) 
	{
		return departmentService.deleteDepartmentById(id);
	}
}