package com.springboot.Employee.Service;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.Employee.Entity.Employee;
import com.springboot.Employee.Repository.EmployeeRepo;
@Service
public class EmployeeImpl implements EmployeeService {
	@Autowired
	EmployeeRepo employeeRepo;
	@Override
	public Employee addEmployee(Employee employee) 
	{
		return employeeRepo.save(employee);
	}
	@Override
	public List<Employee> fetchAllEmployees() 
	{
		List<Employee> allEmployee = employee.Repo.findAll();
		return allEmployee;
	}
	@Override
	public Employee getEmployeeById(int id) 
	{
		Optional<Employee> employee = employeeRepo.findById(id);
		if (employee.isPresent())
		{
			return employee.get();
		}
		return null;
	}
	@Override
	public Employee updateEmployeeById(int id, Employee employee)
	{
		Optional<Employee> employee1 = employee.Repo.findById(id);
		return null;
	}
	@Override
	public String deleteEmployeeById(int id) 
	{
		if(employeeRepo.findById(id).isPresent())
		{
			employeeRepo.deleteById(id);
			return "Employee deleted successfully";
		}
		return "No such employee in the database";
	}
}