package com.springboot.Employee.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.Employee.Entity.Department;
public interface DepartmentRepo extends JpaRepository<Department, Integer>{
}
