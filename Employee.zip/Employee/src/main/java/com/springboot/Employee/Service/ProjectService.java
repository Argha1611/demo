package com.springboot.Employee.Service;
import java.util.List;
import com.springboot.Employee.Entity.Project;
public interface ProjectService {
	Project addDepartment(Project project);
	List<Project> fetchAllProjects();
	Project getProjectById(int id);
	Project updateProjectById(int id, Project project);
	String deleteProjectById(int id);
}
