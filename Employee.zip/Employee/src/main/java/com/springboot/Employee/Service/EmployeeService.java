package com.springboot.Employee.Service;
import java.util.List;
import com.springboot.Employee.Entity.Employee;
public interface EmployeeService {
	Employee addEmployee(Employee employee);
	List<Employee> fetchAllEmployees();
	Employee getEmployeeById(int id);
	Employee updateEmployeeById(int id, Employee employee);
	String deleteEmployeeById(int id);
}
