package com.springboot.Employee.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.Employee.Entity.Employee;
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {
}
