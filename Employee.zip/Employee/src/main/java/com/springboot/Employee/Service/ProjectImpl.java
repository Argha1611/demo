package com.springboot.Employee.Service;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.Employee.Entity.Project;
import com.springboot.Employee.Repository.ProjectRepo;
@Service
public class ProjectImpl implements ProjectService {
	@Autowired
	ProjectRepo projectRepo;
	@Override
	public Project addProject(Project project) 
	{
		return projectRepo.save(project);
	}
	@Override
	public List<Project> fetchAllProjects() 
	{
		List<Project> allProject = project.Repo.findAll();
		return allProject;
	}
	@Override
	public Project getProjectById(int id) 
	{
		Optional<Project> project = projectRepo.findById(id);
		if (project.isPresent())
		{
			return project.get();
		}
		return null;
	}
	@Override
	public Project updateProjectById(int id, Project project)
	{
		Optional<Project> project1 = project.Repo.findById(id);
		return null;
	}
	@Override
	public String deleteProjectById(int id) 
	{
		if(projectRepo.findById(id).isPresent())
		{
			projectRepo.deleteById(id);
			return "Project deleted successfully";
		}
		return "No such project in the database";
	}
}